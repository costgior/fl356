"use client"

import { useState, useRef, useCallback } from 'react'
import { MapContainer, TileLayer, Polyline, Marker, useMap } from 'react-leaflet'
import { LatLngTuple } from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { jsPDF } from 'jspdf'
import html2canvas from 'html2canvas'

// Function to convert DMS to decimal degrees
function dmsToDecimal(degrees: number, minutes: number, seconds: number) {
  return degrees + minutes / 60 + seconds / 3600
}

type Coordinate = {
  lat: number;
  lon: number;
}

function ResetMapView({ coordinates }: { coordinates: Coordinate[] }) {
  const map = useMap();
  if (coordinates.length > 0) {
    const bounds = coordinates.map(coord => [coord.lat, coord.lon] as LatLngTuple);
    map.fitBounds(bounds);
  } else {
    map.setView([0, 0], 2);
  }
  return null;
}

export default function FlightPlanner() {
  const [coordinates, setCoordinates] = useState<Coordinate[]>([])
  const [lat, setLat] = useState({ degrees: 0, minutes: 0, seconds: 0 })
  const [lon, setLon] = useState({ degrees: 0, minutes: 0, seconds: 0 })
  const [showLine, setShowLine] = useState(false)
  const mapRef = useRef(null)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const newLat = dmsToDecimal(lat.degrees, lat.minutes, lat.seconds)
    const newLon = dmsToDecimal(lon.degrees, lon.minutes, lon.seconds)
    setCoordinates([...coordinates, { lat: newLat, lon: newLon }])
    setLat({ degrees: 0, minutes: 0, seconds: 0 })
    setLon({ degrees: 0, minutes: 0, seconds: 0 })
  }

  const handleOkClick = () => {
    setShowLine(true)
  }

  const handleClearClick = () => {
    setCoordinates([])
    setShowLine(false)
    setLat({ degrees: 0, minutes: 0, seconds: 0 })
    setLon({ degrees: 0, minutes: 0, seconds: 0 })
  }

  const handlePrint = useCallback(() => {
    const mapElement = mapRef.current;
    if (mapElement) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write('<html><head><title>Flight Plan Map</title></head><body>');
        printWindow.document.write('<h1>Flight Plan Map</h1>');
        printWindow.document.write(mapElement.innerHTML);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.print();
      }
    }
  }, []);

  const handleExportPDF = useCallback(async () => {
    const mapElement = mapRef.current;
    if (mapElement) {
      const canvas = await html2canvas(mapElement);
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('l', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      const pdfBlob = pdf.output('blob');
      const pdfUrl = URL.createObjectURL(pdfBlob);

      if (navigator.share) {
        try {
          await navigator.share({
            files: [new File([pdfBlob], 'flight-plan-map.pdf', { type: 'application/pdf' })],
            title: 'Flight Plan Map',
            text: 'Check out my flight plan map!',
          });
        } catch (error) {
          console.error('Error sharing:', error);
          // Fallback to download if sharing fails
          const link = document.createElement('a');
          link.href = pdfUrl;
          link.download = 'flight-plan-map.pdf';
          link.click();
        }
      } else {
        // Fallback for browsers that don't support Web Share API
        const link = document.createElement('a');
        link.href = pdfUrl;
        link.download = 'flight-plan-map.pdf';
        link.click();
      }
    }
  }, []);

  return (
    <div className="flex flex-col space-y-4 p-4">
      <Card>
        <CardHeader>
          <CardTitle>Flight Planner</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="lat-deg">Latitude</Label>
              <Input
                id="lat-deg"
                type="number"
                placeholder="Degrees"
                value={lat.degrees}
                onChange={(e) => setLat({ ...lat, degrees: Number(e.target.value) })}
              />
              <Input
                type="number"
                placeholder="Minutes"
                value={lat.minutes}
                onChange={(e) => setLat({ ...lat, minutes: Number(e.target.value) })}
              />
              <Input
                type="number"
                placeholder="Seconds"
                value={lat.seconds}
                onChange={(e) => setLat({ ...lat, seconds: Number(e.target.value) })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lon-deg">Longitude</Label>
              <Input
                id="lon-deg"
                type="number"
                placeholder="Degrees"
                value={lon.degrees}
                onChange={(e) => setLon({ ...lon, degrees: Number(e.target.value) })}
              />
              <Input
                type="number"
                placeholder="Minutes"
                value={lon.minutes}
                onChange={(e) => setLon({ ...lon, minutes: Number(e.target.value) })}
              />
              <Input
                type="number"
                placeholder="Seconds"
                value={lon.seconds}
                onChange={(e) => setLon({ ...lon, seconds: Number(e.target.value) })}
              />
            </div>
            <Button type="submit" className="col-span-2">Add Coordinate</Button>
          </form>
          
          <div className="mt-4">
            <h3 className="text-lg font-semibold mb-2">Added Coordinates:</h3>
            <ul className="list-disc pl-5">
              {coordinates.map((coord, index) => (
                <li key={index}>
                  Lat: {coord.lat.toFixed(4)}, Lon: {coord.lon.toFixed(4)}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="flex flex-wrap gap-4 mt-4">
            <Button 
              onClick={handleOkClick} 
              disabled={coordinates.length < 2}
            >
              OK (Create Line)
            </Button>
            <Button 
              onClick={handleClearClick}
              variant="destructive"
            >
              Clear All
            </Button>
            <Button 
              onClick={handlePrint}
              variant="outline"
            >
              Print Map
            </Button>
            <Button 
              onClick={handleExportPDF}
              variant="outline"
            >
              Export & Share PDF
            </Button>
          </div>
        </CardContent>
      </Card>
      
      <div className="h-[500px] w-full">
        <MapContainer center={[0, 0]} zoom={2} style={{ height: '100%', width: '100%' }} ref={mapRef}>
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          />
          {coordinates.map((coord, index) => (
            <Marker key={index} position={[coord.lat, coord.lon]} />
          ))}
          {showLine && coordinates.length > 1 && (
            <Polyline 
              positions={coordinates.map(coord => [coord.lat, coord.lon])} 
              color="red" 
            />
          )}
          <ResetMapView coordinates={coordinates} />
        </MapContainer>
      </div>
    </div>
  )
}